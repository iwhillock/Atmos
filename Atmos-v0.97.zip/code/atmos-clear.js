// atmos-clear.js
const Max  = require("max-api");
const fs   = require("fs");
const path = require("path");
const os   = require("os");

// Move file to ~/.Trash with a unique name if needed
function moveToMacTrash(srcPath, done) {
    const trashDir = path.join(os.homedir(), ".Trash");

    fs.access(trashDir, fs.constants.W_OK, (err) => {
        if (err) {
            done(new Error("TRASH_NOT_WRITABLE"));
            return;
        }

        const originalBase = path.basename(srcPath);
        const parsed = path.parse(originalBase);

        let candidateBase = originalBase;
        let candidatePath = path.join(trashDir, candidateBase);
        let counter = 1;

        // Check for name collisions synchronously (fast, local)
        while (fs.existsSync(candidatePath)) {
            candidateBase = `${parsed.name} ${counter}${parsed.ext}`;
            candidatePath = path.join(trashDir, candidateBase);
            counter += 1;
        }

        fs.rename(srcPath, candidatePath, (renameErr) => {
            if (renameErr) {
                done(renameErr);
            } else {
                done(null, candidatePath);
            }
        });
    });
}

// Handler: "remove <filepath>"
Max.addHandler("remove", (filePath) => {
    try {
        if (!filePath || typeof filePath !== "string") {
            Max.outlet(["ERROR", "NO_PATH"]);
            return;
        }

        const resolved = path.resolve(filePath);

        if (!fs.existsSync(resolved)) {
            Max.outlet(["NOT_FOUND", resolved]);
            return;
        }

        if (process.platform !== "darwin") {
            Max.outlet(["ERROR_UNSUPPORTED_OS", process.platform]);
            return;
        }

        moveToMacTrash(resolved, (err, trashedPath) => {
            if (err) {
                Max.outlet(["ERROR", err.message || "UNKNOWN"]);
            } else {
                Max.outlet(["COMPLETE", trashedPath]);
            }
        });

    } catch (e) {
        Max.outlet(["ERROR", e.message || "UNKNOWN"]);
    }
});
