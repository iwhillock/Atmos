//
// Watches for a file to appear, then outputs "COMPLETE <path>"
// Usage in Max: waitfor <filepath> [intervalMs] [timeoutMs]

const fs = require('fs');
const path = require('path');
const max = require('max-api');

// Expand "~" like a shell
function expandHome(p) {
    if (!p) return p;
    if (p === '~') return process.env.HOME;
    if (p.startsWith('~/')) {
        return path.join(process.env.HOME, p.slice(2));
    }
    return p;
}

// Helper to repeatedly check for file existence
function waitForFile(filePath, interval = 500, timeout = 60000) {
    const resolved = path.resolve(expandHome(filePath));
    const startTime = Date.now();

    const intervalId = setInterval(() => {
        fs.access(resolved, fs.constants.F_OK, (err) => {
            if (!err) {
                clearInterval(intervalId);
                // Success
                max.outlet(["COMPLETE", resolved]);
            } else if (Date.now() - startTime > timeout) {
                clearInterval(intervalId);
                // Timeout
                max.outlet(["TIMEOUT", resolved]);
            }
        });
    }, interval);
}

// Inlet handler
// Example: waitfor "/Users/ianwhillock/Desktop/testttt Project/Atmos/render.mov" 500 120000
max.addHandler("waitfor", (...args) => {
    const file = args[0];
    const interval = parseInt(args[1]) || 500;    // default check every 500ms
    const timeout = parseInt(args[2]) || 60000;   // default stop after 60 seconds
    waitForFile(file, interval, timeout);
});
