// atmos-dir-check.js
// In Max: send `dir <path>` to node.script.
// If the directory doesn't exist, it will be created recursively.
// If it already exists, nothing bad happens.

const fs = require('fs');
const path = require('path');
const max = require('max-api');

// Expand "~" to home dir like a shell
function expandHome(p) {
    if (!p) return p;
    if (p === '~') return process.env.HOME;
    if (p.startsWith('~/')) {
        return path.join(process.env.HOME, p.slice(2));
    }
    return p;
}

// message: dir <path...>
max.addHandler("dir", (...parts) => {
    // Rebuild the path in case it contains spaces
    const rawPath = parts.join(' ');
    const trimmed = rawPath.trim();

    if (!trimmed) {
        max.outlet(["error", "no path"]);
        return;
    }
