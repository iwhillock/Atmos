// atmos-clone.js
const max = require("max-api");
const fs = require("fs");
const path = require("path");

let destinationFolder = null;

/**
 * Helper to send messages only through outlet.
 */
function report(...msg) {
    max.outlet(msg);
}

/**
 * Handle destination folder setting
 */
max.addHandler("destination", (folderPath) => {
    destinationFolder = String(folderPath);

    // make sure folder exists
    try {
        fs.mkdirSync(destinationFolder, { recursive: true });
        report("destination", "received", destinationFolder);
    } catch (err) {
        report("error", "creating_destination", err.message);
    }
});

/**
 * Handle copy command
 */
max.addHandler("copy", (sourcePath) => {
    if (!destinationFolder) {
        report("error", "no_destination_set");
        return;
    }

    const src = String(sourcePath);
    const filename = path.basename(src);
    const dest = path.join(destinationFolder, filename);

    report("copy", "started", filename);

    fs.copyFile(src, dest, (err) => {
        if (err) {
            report("copy", "error", err.message);
        } else {
            report("done", dest);
        }
    });
});

/**
 * Optional: query current destination
 */
max.addHandler("status", () => {
    if (destinationFolder) {
        report("status", "destination", destinationFolder);
    } else {
        report("status", "no_destination_set");
    }
});
